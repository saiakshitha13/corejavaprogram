package com.dailycodebuffer.Springboot.tutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestApplication2 {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestApplication2.class, args);
	}

}
